function childParent()
{
	let t = document.createElement("h1");
	t.innerHTML =" Hello , This is Heading ... ";
	let div1 = document.getElementById("mydiv");
	div1.appendChild(t);
	t.setAttribute("id","head");
	alert(document.getElementById("head").innerHTML);
	t.style.backgroundColor='red';
	t.style.color="white";
	t.parentNode.removeChild(t);
	alert(document.getElementById("head").innerHTML);
}
