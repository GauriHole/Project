function validFun() 
{
		let x= document.getElementById("username").value;
		let y= document.getElementById("pass").value;

		let valid =/^[a-z]+[0-9]+[@][a-z]+[.][a-z]+$/; //Email Validation
		let nameid =/^[a-z]+[@][0-9]+$/; //Username Validation
		let numid =/^[a-z,@,$,0-9]+$/; //Mobile Number Validation


		if (valid.test(x) || nameid.test(x))
		{
			if (numid.test(y))
			{
				alert("Login Validation SuccessFul...");
			}
			else
			{
				alert(" Password Validation UnsuccessFul...");
			}
		}
		else{
			alert("Username Validation UnsuccessFul...");
		}

}

function objectEx()
{
	var test = "Some String";
	let x={
		name:"Gauri",
		mark:80,
		class:"TY BTECH"
	};
	//alert(typeof(x));
	//alert(x.name+" "+x.class);
	//delete x.class;
	//alert(x.class);
	for (let key in x)
	{
		alert(x.[key]);
	}

	//alert(test[7]);
	//alert(test.charAt(5));
	//alert("test".substring(1,3));
	//alert(parseInt("9")+9);
	//prompt("enter amount",10);
}

/*function reloadP(){
    document.location.reload();
    arith();
}*/

function arith()
{
	let a=document.getElementById("num1").value;
	let b=document.getElementById("num2").value;
	n1=parseInt(a);
	n2=parseInt(b);
	let add = n1+n2;
document.getElementById("result").value=add;
}