

# To-Do list using AngularJS

![Screenshot (11)](https://github.com/IshwariK117/To-Do-List-Using-AngularJS/assets/99877551/97f39da9-9536-4e21-bd7b-2fa84e9379bc)


## 🛠 Skills


HTML

CSS

Javascript

Bootstrap

AngularJS


## 🔗 Links

[![linkedin](https://www.linkedin.com/in/ishwarikape?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app)](https://www.linkedin.com/)
[![twitter](https://twitter.com/i/flow/login?redirect_after_login=%2FIshwariK117
)](https://twitter.com/)



