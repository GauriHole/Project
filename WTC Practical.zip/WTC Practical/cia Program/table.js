 // Case 1) Add New Table Row Inside Table .

/*function Func1()
{
	let x="xyz";
	let y=80;

	let z= document.createElement("tr");
	z.innerHTML ="<td>"+x+"</td> <td>"+y+"</td>";

	let a= document.getElementById("table1");
	a.appendChild(z);
} 
*/
 // Case 2) Add New List Item Which is Not Present Already. 

/*function Func1()
{
	let x=document.getElementById("newdp").value;
	let ch1=document.getElementById("c1").value;
	let ch2=document.getElementById("c2").value;

	if(ch1!=x && ch2!=x)
	{
		let z = document.createElement("li");
		z.innerHTML = x;
		let a = document.getElementById("ul1");
		a.appendChild(z);
	}
	else{
		alert("Department is already present ");
	}
	
}*/

//OR

/*var availableDepartments = ["math", "physics", "chemistry"];
var newDepartment = "comp";
if (availableDepartments.indexOf(newDepartment) == -1) {
  availableDepartments.push(newDepartment);
}

console.log(availableDepartments); //Output ["math", "physics", "chemistry", "comp"]
*/

/*function myFun(){
const apiUrl ='data.json';

fetch(apiUrl)
.then(response => {
	if(!response.ok){
		throw new Error(`HTTP error ! Status: ${response.status}`);
	}
})

.then(data => {
	let x = "<table><tr><th>Name</th><th>Marks</th></tr>";
	let y =document.getElementById("myDiv");
	for(let i=0;i<data.length;i++)
	{
		x = x+"<tr>";
		let o=data[i];
		for(let key in o)
		{
			let z = o[key];
			x = x+"<td>"+z+"</td>"
		}
		x = x+"</tr>"
	}
	x=x+"</table>";
	y.innerHTML=x;
})

.catch(error => {
	console.error('Fetch error : ',error);
});
}
*/