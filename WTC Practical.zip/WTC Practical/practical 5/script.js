let x = angular.module('mymodule',[]);
x.controller('mycontroller',['$scope',function ($scope) 
	{
		$scope.arr[
		{'name':'xyz','description':"the feasility of parking is good"}
		];

		$scope.addInfo = function(){
			$scope.arr.push(angular.copy($scope.newInfo));
			$scope.newInfo = { name:'',description:''};
		};

		$scope.clearInfo = function(){
			$scope.arr = $scope.arr.filter(function(item)
			{
				return !item.done;
			});
		};

		$scope.editInfo = function(index){
			const updateName = prompt('Edit your Name : ',$scope.arr[index].name);
			if(updateName!=null){
				$scope.arr[index].name = updateName;
			}
		};

	}]);
	/*$scope.add1 = function(){

	alert("called  .... ");
	    let obj = {};
	obj.fname = $scope.name1;
	obj.descrip = $scope.desp1;
	$scope.arr.push($scope.new);
};*/