let x = angular.module('myModule',[]);
x.controller('mycontroller',
	function ($scope) {
		$scope.arr[
		{'name':'xyz','description':'the feasility of parking is good'},
		{'name':'abc','description':'this restorant is really good.'}
		];

	$scope.add1 = function(){

	alert("called  .... ");
	/*let obj = {};
	obj.fname = $scope.name1;
	obj.descrip = $scope.desp1;
	$scope.arr.push($scope.new);*/
};
});

