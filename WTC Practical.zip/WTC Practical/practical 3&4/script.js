function validFun() 
{
		let x= document.getElementById("mail").value;
		let y= document.getElementById("name").value;
		let z= document.getElementById("linkid").value;
		let a= document.getElementById("number").value;
		let b= document.getElementById("linkid").value;


		let valid1 =/^[a-z,0-9]+[@][a-z]+[.][a-z]+$/;
		let valid2 =/^[a-z,0-9,_]+[@][a-z]+[.][a-z]+[.][a-z]+$/;
 													//Email Validation
		let nameid =/^[a-z]+[@][0-9]+$/; //Username Validation
		let numid =/^[+][91][0-9]+$/; //Mobile Number Validation
		let linkvalid =/^[a-z]+[.][a-z]+[.][a-z]+[/][a-z]+[/][a-z]+[-][a-z]+[-][a-z]+[-][0-9,a-z]+$/;

// www.linkedin.com/in/gauri-rajendra-hole-47644b228

		if (valid1.test(x) || valid2.test(x))
		{
			if(nameid.test(y)) 
				{
					if(numid.test(a) && a.length>=10) 
					{
						if(linkvalid.test(b))
						{
							alert("Validation SuccessFul...");
						}
						else{
							alert("Linkdin Account Doesn't found ")
						}
					}
					else{
						alert(" Mobile Number Should be 10-digits ");
					}
				}
				else{
					alert(" Username is Wrong ")
				}
		}
		else{
			alert("Email Validation UnsuccessFul , Failed !");
		}

}
